package com.temple.backup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackupApplicationTests {

	@Test
	void contextLoads() {
	}

}
